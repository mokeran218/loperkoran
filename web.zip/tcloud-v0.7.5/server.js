! function(e) {
    function t(r) {
        if (n[r]) return n[r].exports;
        var o = n[r] = {
            i: r,
            l: !1,
            exports: {}
        };
        return e[r].call(o.exports, o, o.exports, t), o.l = !0, o.exports
    }
    var n = {};
    t.m = e, t.c = n, t.d = function(e, n, r) {
        t.o(e, n) || Object.defineProperty(e, n, {
            configurable: !1,
            enumerable: !0,
            get: r
        })
    }, t.n = function(e) {
        var n = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return t.d(n, "a", n), n
    }, t.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, t.p = "", t(t.s = 12)
}([function(e, t, n) {
    "use strict";

    function r(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function o(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function i(e, t) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !t || "object" != typeof t && "function" != typeof t ? e : t
    }

    function a(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
        e.prototype = Object.create(t && t.prototype, {
            constructor: {
                value: e,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.ConfigLocation = void 0;
    var s = function() {
            function e(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                }
            }
            return function(t, n, r) {
                return n && e(t.prototype, n), r && e(t, r), t
            }
        }(),
        u = n(2),
        l = r(u),
        c = n(1),
        f = r(c),
        d = n(5),
        h = r(d),
        p = n(23),
        v = n(24),
        m = r(v),
        y = t.ConfigLocation = "config.json",
        g = function(e) {
            function t(e) {
                o(this, t);
                var n = i(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this));
                e = e || {}, n.location = process.env.CONFIG_PATH || y, n.log = new f.default("Config");
                var r = void 0;
                if (e.sync) try {
                    var a = l.default.readFileSync(n.location);
                    r = n.parseConfig(a), n.assignConfig(r)
                } catch (e) {
                    "ENOENT" === e.code ? n.generateConfig() : n.log.error(e)
                } else l.default.readFile(n.location, function(e, t) {
                    e && "ENOENT" === e.code ? n.generateConfig() : e ? n.log.error(e) : (r = n.parseConfig(t), n.assignConfig(r))
                });
                return n
            }
            return a(t, e), s(t, [{
                key: "generateConfig",
                value: function() {
                    var e = this;
                    this.assignConfig(m.default), l.default.writeFile(this.location, JSON.stringify(m.default, "undefined", 2), function(t) {
                        t && e.log.error(t)
                    })
                }
            }, {
                key: "parseConfig",
                value: function(e) {
                    var t = JSON.parse(e);
                    return (0, p.expect)(t).to.have.property("log").to.be.a("object"), (0, p.expect)(t.log).to.have.property("path").to.be.a("string").not.empty, (0, p.expect)(t).to.have.property("server").to.be.a("object"), (0, p.expect)(t.server).to.have.property("port").to.be.a("number").within(0, 65535), (0, p.expect)(t.server).to.have.property("masterKey").to.be.a("string").to.have.lengthOf.above(5), (0, p.expect)(t.server).to.have.property("https"), t.server.https ? ((0, p.expect)(t.server.https).to.be.a("number"), (0, p.expect)(t.server).to.have.property("hostname").to.be.a("string").not.empty, (0, p.expect)(t.server).to.have.property("certs").to.be.a("object"), (0, p.expect)(t.server.certs).to.have.property("privatekey").to.be.a("string").not.empty, (0, p.expect)(t.server.certs).to.have.property("certificate").to.be.a("string").not.empty, (0, p.expect)(t.server.certs).to.have.property("chain").to.be.a("string").not.empty) : (0, p.expect)(t.server.https).to.be.a("boolean"), (0, p.expect)(t).to.have.property("database").to.be.a("object"), (0, p.expect)(t.database).to.have.property("path").to.be.a("string").not.empty, (0, p.expect)(t).to.have.property("authentification").to.be.a("boolean"), (0, p.expect)(t).to.have.property("registration").to.be.a("boolean"), (0, p.expect)(t).to.have.property("files").to.be.a("object"), (0, p.expect)(t.files).to.have.property("path").to.be.a("string").not.empty, (0, p.expect)(t.files).to.have.property("tmp").to.be.a("string").not.empty, (0, p.expect)(t).to.have.property("torrent").to.be.a("object"), (0, p.expect)(t.torrent).to.have.property("providers").to.be.a("array"), t
                }
            }, {
                key: "assignConfig",
                value: function(e) {
                    e.server.port = parseInt(process.env.PORT) || e.server.port, e.torrent.providers = process.env.TORRENT_PROVIDERS ? process.env.TORRENT_PROVIDERS.split(",") : e.torrent.providers, Object.assign(this, e), this.emit("ready")
                }
            }]), t
        }(h.default);
    t.default = g
}, function(e, t) {
    e.exports = require("delogger")
}, function(e, t) {
    e.exports = require("fs")
}, function(e, t) {
    e.exports = require("path")
}, function(e, t) {
    e.exports = require("crypto-js")
}, function(e, t) {
    e.exports = require("events")
}, function(e, t, n) {
    "use strict";

    function r(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function o(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function i(e, t) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !t || "object" != typeof t && "function" != typeof t ? e : t
    }

    function a(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
        e.prototype = Object.create(t && t.prototype, {
            constructor: {
                value: e,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
    }

    function s(e, t) {
        var n = t,
            e = e.split("/");
        (0, f.removeBlank)(e, 0);
        for (var r = 0; n instanceof h && r < e.length;) n = n.findChild(e[r]), r++;
        return r < e.length - 1 ? null : n
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.follow = void 0;
    var u = function() {
            function e(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                }
            }
            return function(t, n, r) {
                return n && e(t.prototype, n), r && e(t, r), t
            }
        }(),
        l = n(10),
        c = r(l),
        f = n(7),
        d = r(f),
        h = function(e) {
            function t(e, n) {
                o(this, t);
                var r = i(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, e, n));
                return r.type = "folder", r.childs = [], r.exist && r.initFolder(), r.idle = {
                    date: new Date,
                    timeout: 1e3
                }, r
            }
            return a(t, e), u(t, [{
                key: "initManualWatch",
                value: function(e) {
                    var t = this;
                    setInterval(function() {
                        t.watchChange(null, null)
                    }, e)
                }
            }, {
                key: "initFolder",
                value: function() {
                    var e = this,
                        n = this.childs,
                        r = [],
                        o = [];
                    try {
                        o = c.default.readdirSync(this.fullPath())
                    } catch (e) {
                        this.exist = !1
                    }
                    for (var i = 0; i < o.length; i++) ! function(i) {
                        var a = c.default.statSync(e.fullPath() + "/" + o[i]),
                            s = void 0;
                        if (a.isFile()) s = new d.default(e.fullPath() + "/" + o[i], e.base + "/" + e.name);
                        else {
                            if (!a.isDirectory()) return "continue";
                            s = new t(e.fullPath() + "/" + o[i], e.base + "/" + e.name)
                        }
                        var u = n.findIndex(function(e) {
                            return e.name === s.name
                        }); - 1 !== u ? (n[u]._size = s._size, r.push(n[u])) : (s.on("change", function(t) {
                            return e.emit("change", t)
                        }), s.on("startDownload", function(t) {
                            return e.emit("change", t)
                        }), s.on("finishDownload", function(t) {
                            return e.emit("change", t)
                        }), s.on("locked", function(t) {
                            return e.emit("change", t)
                        }), s.on("unlocked", function(t) {
                            return e.emit("change", t)
                        }), s.on("remove", function(t) {
                            e.handleChildRemove(s), e.emit("change", e)
                        }), r.push(s))
                    }(i);
                    this.childs = r
                }
            }, {
                key: "watchChange",
                value: function(e, t) {
                    var n = this;
                    this.updateMetadata(), this.emitChange().then(function() {
                        n.initFolder()
                    })
                }
            }, {
                key: "handleChildRemove",
                value: function(e) {
                    for (var t = 0; t < this.childs.length; t++)
                        if (this.childs[t].name === e.name) {
                            this.childs.splice(t, 1);
                            break
                        }
                }
            }, {
                key: "remove",
                value: function() {
                    var e = this;
                    this.log.info("Removing " + this.fullPath()), c.default.remove(this.fullPath(), function() {
                        return e.emit("remove", e)
                    })
                }
            }, {
                key: "size",
                value: function() {
                    for (var e = this._size, t = 0; t < this.childs.length; t++) e += this.childs[t].size();
                    return e
                }
            }, {
                key: "create",
                value: function() {
                    this.log.info("Creating " + this.fullPath()), c.default.mkdirSync(this.fullPath()), this.exist = !0, this.initWatch()
                }
            }, {
                key: "addChild",
                value: function(e) {
                    this.childs.push(e)
                }
            }, {
                key: "findChild",
                value: function(e) {
                    for (var t = 0; t < this.childs.length; t++)
                        if (this.childs[t].name === e) return this.childs[t];
                    return null
                }
            }]), t
        }(d.default);
    t.default = h, t.follow = s
}, function(e, t, n) {
    "use strict";

    function r(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function o(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function i(e, t) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !t || "object" != typeof t && "function" != typeof t ? e : t
    }

    function a(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
        e.prototype = Object.create(t && t.prototype, {
            constructor: {
                value: e,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
    }

    function s(e) {
        var t = e.split("/");
        return u(t, 1), {
            fileName: t.splice(t.length - 1, 1)[0],
            path: t.join("/")
        }
    }

    function u(e, t) {
        t = t || 0;
        for (var n = t; n < e.length; n++) "" !== e[n] && null !== e[n] || (e.splice(n, 1), n--);
        return e
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.parsePath = t.removeBlank = void 0;
    var l = function() {
            function e(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                }
            }
            return function(t, n, r) {
                return n && e(t.prototype, n), r && e(t, r), t
            }
        }(),
        c = n(2),
        f = r(c),
        d = n(3),
        h = r(d),
        p = n(5),
        v = r(p),
        m = n(1),
        y = r(m),
        g = n(4),
        b = r(g),
        w = n(6),
        k = r(w),
        _ = n(0),
        j = r(_),
        P = new j.default({
            sync: !0
        }),
        x = function(e) {
            function t(e, n) {
                o(this, t);
                var r = i(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this)),
                    a = s(e);
                return r.base = n, r._path = a.path, r.type = "file", r.name = a.fileName, r.mtime = null, r.locked = !1, r.downloadCount = 0, r.downloading = 0, r.idle = {
                    date: new Date,
                    timeout: 1e3
                }, r.initMetadata(), r.initWatch(), r.log = new y.default("File"), r
            }
            return a(t, e), l(t, [{
                key: "initWatch",
                value: function() {
                    var e = this;
                    this.exist && f.default.watch(this.fullPath(), {
                        recursive: !0
                    }, function(t, n) {
                        return e.watchChange(t, n)
                    })
                }
            }, {
                key: "initMetadata",
                value: function() {
                    try {
                        var e = f.default.statSync(this.fullPath());
                        this.mtime = e.mtime, this._size = e.size, this.exist = !0
                    } catch (e) {
                        this.mtime = null, this._size = 0, this.exist = !1
                    }
                }
            }, {
                key: "updateMetadata",
                value: function() {
                    var e = this;
                    f.default.stat(this.fullPath(), function(t, n) {
                        t ? (e.mtime = null, e._size = 0, e.exist = !1) : (e.mtime = n.mtime, e._size = n.size, e.exist = !0)
                    })
                }
            }, {
                key: "watchChange",
                value: function(e, t) {
                    this.updateMetadata(), this.emitChange()
                }
            }, {
                key: "emitChange",
                value: function() {
                    var e = this;
                    return new Promise(function(t, n) {
                        new Date - e.idle.date >= e.idle.timeout && (e.idle.date = new Date, t(), e.emit("change", e))
                    })
                }
            }, {
                key: "fullPath",
                value: function() {
                    return this._path + "/" + this.name
                }
            }, {
                key: "relativePath",
                value: function() {
                    var e = this.base.split("/").slice(2).join("/");
                    return h.default.join(e, this.name)
                }
            }, {
                key: "size",
                value: function() {
                    return this._size
                }
            }, {
                key: "lock",
                value: function() {
                    this.locked = !0, this.emit("locked", this)
                }
            }, {
                key: "unlock",
                value: function() {
                    this.locked = !1, this.emit("unlocked", this)
                }
            }, {
                key: "remove",
                value: function() {
                    var e = this;
                    if (this.locked) return !1;
                    this.log.info("Removing " + this.fullPath()), f.default.unlink(this.fullPath(), function() {
                        return e.emit("remove", e)
                    })
                }
            }, {
                key: "addDownloader",
                value: function() {
                    this.downloadCount++, this.downloading++, this.emit("startDownload", this), this.lock()
                }
            }, {
                key: "removeDownloader",
                value: function() {
                    this.downloading--, this.emit("finishDownload", this), this.downloading <= 0 && (this.downloading = 0, this.unlock())
                }
            }, {
                key: "rename",
                value: function(e) {
                    var t = this;
                    if (this.locked) return !1;
                    this.log.info("Renaming " + this.fullPath() + " into " + this._path + "/" + e), f.default.rename(this.fullPath(), this._path + "/" + e, function() {
                        return t.emit("rename", t)
                    })
                }
            }, {
                key: "create",
                value: function() {
                    var e = this;
                    this.log.info("Creating " + this.fullPath()), f.default.writeFile(this.fullPath(), "", function() {
                        return e.initWatch()
                    })
                }
            }, {
                key: "toJSON",
                value: function() {
                    var e = this.base.split("/").slice(2).join("/"),
                        t = h.default.join("/folder", e, this.name),
                        n = "/dl/" + b.default.Rabbit.encrypt(h.default.join(e, this.name), P.server.masterKey).toString(),
                        r = this.relativePath();
                    return {
                        name: this.name,
                        type: this.type,
                        mtime: this.mtime,
                        locked: this.locked,
                        downloadCount: this.downloadCount,
                        size: this.size(),
                        childs: this.childs,
                        url: t,
                        download: this instanceof k.default ? null : n,
                        path: this instanceof k.default ? r : null
                    }
                }
            }, {
                key: "download",
                value: function(e) {
                    var t = this;
                    return new Promise(function(n, r) {
                        t.addDownloader(), e.download(t.fullPath(), function(e) {
                            e && t.log.error(e), t.removeDownloader(), n(e)
                        })
                    })
                }
            }]), t
        }(v.default);
    t.default = x, t.removeBlank = u, t.parsePath = s
}, function(e, t, n) {
    "use strict";

    function r(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function o(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function i(e, t) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !t || "object" != typeof t && "function" != typeof t ? e : t
    }

    function a(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
        e.prototype = Object.create(t && t.prototype, {
            constructor: {
                value: e,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var s = function() {
            function e(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                }
            }
            return function(t, n, r) {
                return n && e(t.prototype, n), r && e(t, r), t
            }
        }(),
        u = n(1),
        l = r(u),
        c = n(4),
        f = r(c),
        d = n(9),
        h = r(d),
        p = n(5),
        v = r(p),
        m = n(22),
        y = r(m),
        g = n(0),
        b = r(g),
        w = new b.default({
            sync: !0
        }),
        k = new y.default({
            filename: w.database.path + "/user.json",
            autoload: !0,
            timestampData: !0
        }),
        _ = function(e) {
            function t(e) {
                o(this, t);
                var n = i(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this));
                return e = e || {}, n.username = e.username || "", n.password = f.default.SHA256(e.password || ""), n.tokens = e.tokens || [], n.log = new l.default("User(" + n.username + ")"), k.ensureIndex({
                    fieldName: "expirationDate",
                    expireAfterSeconds: 0
                }, function(e) {
                    e && n.log.error(e)
                }), n.on("update", function() {
                    return n.save()
                }), k.findOne({
                    username: n.username
                }, function(e, t) {
                    e && n.log.error(e), t && Object.assign(n, t), n.emit("ready")
                }), n
            }
            return a(t, e), s(t, [{
                key: "exist",
                value: function(e) {
                    var t = this;
                    k.findOne({
                        username: this.username
                    }, function(n, r) {
                        n && t.log.error(n), e(null !== r)
                    })
                }
            }, {
                key: "save",
                value: function() {
                    var e = this,
                        t = {
                            username: this.username,
                            password: this.password,
                            tokens: this.tokens
                        };
                    k.update({
                        username: this.username
                    }, t, {}, function(n, r) {
                        n && e.log.error(n), 0 === r && k.insert(t, function(t) {
                            t && e.log.error(t)
                        })
                    })
                }
            }, {
                key: "generateToken",
                value: function(e) {
                    var t = "" + h.default.rand().toString();
                    return {
                        id: f.default.SHA256(t).toString(),
                        expirationDate: new Date(Date.now() + e)
                    }
                }
            }, {
                key: "set",
                value: function(e) {
                    for (var t in e) this[t] = e[t];
                    this.emit("update")
                }
            }, {
                key: "login",
                value: function(e, t) {
                    var n = t ? 31536e6 : 864e5,
                        r = this.generateToken(n);
                    return this.tokens.push(r), this.emit("update"), this.log.info(this.username + " login from " + e), r
                }
            }, {
                key: "logout",
                value: function(e) {
                    for (var t = 0; t < this.tokens.length; t++)
                        if (this.tokens[t].id === e) {
                            delete this.tokens[t], this.emit("update");
                            break
                        } this.log.info(this.username + " logout")
                }
            }, {
                key: "isTokenValid",
                value: function(e) {
                    for (var t = 0; t < this.tokens.length; t++)
                        if (this.tokens[t].id === e) return !0;
                    return !1
                }
            }, {
                key: "isPasswordValid",
                value: function(e) {
                    return f.default.SHA256(e).toString() === this.password
                }
            }]), t
        }(v.default);
    t.default = _
}, function(e, t) {
    e.exports = require("crypto-rand")
}, function(e, t) {
    e.exports = require("fs-extra")
}, function(e, t) {
    e.exports = require("child_process")
}, function(e, t, n) {
    "use strict";

    function r(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }
    var o = n(13),
        i = r(o);
    new(r(n(0)).default)({}).on("ready", function() {
        (new i.default).listen()
    })
}, function(e, t, n) {
    "use strict";

    function r(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function o(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var i = function() {
            function e(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                }
            }
            return function(t, n, r) {
                return n && e(t.prototype, n), r && e(t, r), t
            }
        }(),
        a = n(14),
        s = r(a),
        u = n(1),
        l = r(u),
        c = n(15),
        f = r(c),
        d = n(16),
        h = r(d),
        p = n(17),
        v = r(p),
        m = n(18),
        y = r(m),
        g = n(19),
        b = r(g),
        w = n(2),
        k = r(w),
        _ = n(3),
        j = r(_),
        P = n(20),
        x = r(P),
        O = n(21),
        S = r(O),
        C = n(0),
        M = r(C),
        E = new M.default({
            sync: !0
        }),
        T = function() {
            function e() {
                if (o(this, e), this.app = (0, s.default)(), this.app.disable("x-powered-by"), this.app.use((0, f.default)()), this.app.use((0, h.default)()), this.app.use(v.default.json()), this.app.use(v.default.urlencoded({
                        extended: !0
                    })), E.server.https) {
                    this.app.use((0, x.default)({
                        port: E.server.https
                    }));
                    var t = {};
                    Object.assign(t, {
                        hostname: E.server.hostname,
                        key: k.default.readFileSync(E.server.certs.privatekey),
                        cert: k.default.readFileSync(E.server.certs.certificate),
                        ca: k.default.readFileSync(E.server.certs.chain)
                    }), this.serverSSL = y.default.createServer(t, this.app)
                }
                this.server = b.default.createServer(this.app), this.app.use((0, S.default)()), n(25)(this.app), n(26)(this.app, this), n(29)(this.app), this.baseFolder = n(30)(this.app), n(31)(this.app, this.baseFolder), n(32)(this.app, this.baseFolder), n(37)(this.app, this.baseFolder), this.app.use(s.default.static(j.default.join(__dirname, "/public"))), this.log = new l.default("Server")
            }
            return i(e, [{
                key: "listen",
                value: function() {
                    var e = this,
                        t = "0.0.0.0";
                    E.server.https && (this.serverSSL.listen(E.server.https, t, function() {
                        return e.log.info("Server listening on 0.0.0.0:" + E.server.https)
                    }), this.app.socketSSL = this.app.ioSSL.listen(this.serverSSL, t)), this.server.listen(E.server.port, t, function() {
                        return e.log.info("Server listening on 0.0.0.0:" + E.server.port)
                    }), this.app.socket = this.app.io.listen(this.server, t)
                }
            }]), e
        }();
    t.default = T
}, function(e, t) {
    e.exports = require("express")
}, function(e, t) {
    e.exports = require("compression")
}, function(e, t) {
    e.exports = require("cookie-parser")
}, function(e, t) {
    e.exports = require("body-parser")
}, function(e, t) {
    e.exports = require("https")
}, function(e, t) {
    e.exports = require("http")
}, function(e, t, n) {
    "use strict";

    function r(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function o(e) {
        var t = {};
        e = e || {};
        for (var n in l) t[n] = e[n] || l[n];
        return t
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.default = function(e) {
        return e = o(e),
            function(t, n, r) {
                var o = t.secure;
                if (!o && e.trustProtoHeader && (o = "https" === (t.headers["x-forwarded-proto"] || "").substring(0, 5)), !o && e.trustAzureHeader && t.headers["x-arr-ssl"] && (o = !0), o) r();
                else if ("GET" === t.method || "HEAD" === t.method) {
                    var i = e.trustXForwardedHostHeader ? t.headers["x-forwarded-host"] || t.headers.host : t.headers.host;
                    i = i || "", 443 === e.port ? n.redirect(301, "https://" + a.default.join(i, t.originalUrl)) : n.redirect(301, "https://" + a.default.join(i.replace(/:[0-9]*/g, "") + ":" + e.port, t.originalUrl))
                } else n.status(403).send("Please use HTTPS when submitting data to this server.")
            }
    };
    var i = n(3),
        a = r(i),
        s = n(1),
        u = r(s),
        l = (new u.default("https"), {
            trustProtoHeader: !1,
            trustAzureHeader: !1,
            trustXForwardedHostHeader: !1,
            port: 443
        })
}, function(e, t, n) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.default = function() {
        return function(e, t, n) {
            if (e.body.username || e.cookies.username) {
                var r = new o.default({
                    username: e.body.username || e.cookies.username
                });
                r.on("ready", function() {
                    e.user = r, n()
                })
            } else e.user = new o.default, n()
        }
    };
    var r = n(8),
        o = function(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }(r)
}, function(e, t) {
    e.exports = require("nedb")
}, function(e, t) {
    e.exports = require("chai")
}, function(e, t, n) {
    "use strict";
    var r = {
        log: {
            path: "logs/"
        },
        server: {
            port: 5e3,
            masterKey: "mymasterkey",
            https: !1,
            hostname: "",
            certs: {
                privatekey: "",
                certificate: "",
                chain: ""
            }
        },
        database: {
            path: "database/"
        },
        authentification: !1,
        registration: !0,
        files: {
            path: "files/",
            tmp: ".tmp/"
        },
        torrent: {
            providers: []
        }
    };
    e.exports = r, __filename.match(/.*template.*/g) && console.log(JSON.stringify(r, "undefined", 2))
}, function(e, t, n) {
    "use strict";

    function r(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function o(e) {
        return e.user.username || "Anonymous"
    }

    function i(e) {
        return e.headers["x-forwarded-for"] || e.connection.remoteAddress
    }

    function a(e) {
        return e.method
    }

    function s(e) {
        return e.url
    }

    function u(e) {
        return e.statusCode
    }
    var l = n(1),
        c = r(l),
        f = n(0),
        d = r(f),
        h = new d.default({
            sync: !0
        }),
        p = new c.default("Express", __dirname + "/" + h.log.path);
    e.exports = function(e) {
        e.use(function(e, t, n) {
            var r = new Date;
            n();
            var l = new Date - r,
                c = u(t),
                f = o(e),
                d = i(e),
                h = a(e),
                v = s(e),
                m = u(t),
                y = f + "@" + d + " - " + h + " " + v + " - " + m + " " + l + "ms";
            c < 400 ? p.info(y) : c < 500 ? p.warning(y) : p.error(y)
        })
    }
}, function(e, t, n) {
    "use strict";

    function r(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function o(e, t) {
        var n = u.default.parse(e.headers.cookie),
            r = new d.default({
                username: n.username || ""
            });
        r.on("ready", function() {
            var e = r.isTokenValid(n.token || "");
            t(e ? null : "Token not valid", e)
        })
    }
    var i = n(27),
        a = r(i),
        s = n(28),
        u = r(s),
        l = n(0),
        c = r(l),
        f = n(8),
        d = r(f),
        h = new c.default({
            sync: !0
        });
    e.exports = function(e, t) {
        h.server.https && (e.ioSSL = (0, a.default)(t.serverSSL), e.ioSSL.set("authorization", o)), e.io = (0, a.default)(t.server), e.io.set("authorization", o)
    }
}, function(e, t) {
    e.exports = require("socket.io")
}, function(e, t) {
    e.exports = require("cookie")
}, function(e, t, n) {
    "use strict";

    function r(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }
    var o = n(4),
        i = r(o),
        a = n(0),
        s = r(a),
        u = new s.default({
            sync: !0
        });
    e.exports = function(e) {
        e.use(function(e, t, n) {
            var r = e.user;
            if (e.url.match(/\/(auth|src|dl|app)\/.*/g) || e.url.match(/manifest\.json/g) || !u.authentification) n();
            else {
                var o = r.isTokenValid(e.cookies.token);
                "/login.html" === e.url ? o ? t.redirect("/") : n() : o ? n() : "/" === e.url ? t.redirect("/login.html") : (t.status(403), t.end("Unauthorized"))
            }
        }), e.post("/auth/login", function(e, t) {
            var n = e.user,
                r = {
                    username: e.body.username || e.cookies.username,
                    password: e.body.password,
                    staylogged: e.body.staylogged || !1
                };
            if (r.username && r.password) {
                var o = e.headers["x-forwarded-for"] || e.connection.remoteAddress;
                if (n.isPasswordValid(r.password)) {
                    var i = n.login(o, r.staylogged);
                    t.cookie("token", i.id, {
                        expires: i.expirationDate,
                        httpOnly: !0,
                        encode: String
                    }), t.cookie("username", n.username, {
                        expires: i.expirationDate,
                        httpOnly: !0,
                        encode: String
                    }), t.json({
                        err: !1,
                        token: i.id
                    })
                } else t.status(401), t.json({
                    err: "Wrong User or Pass."
                })
            } else t.status(400), t.json({
                err: "Missing User or Pass."
            })
        }), e.post("/auth/logout", function(e, t) {
            var n = e.user,
                r = {
                    username: e.body.username || e.cookies.username,
                    token: e.body.token || e.cookies.token
                };
            r.username && r.token ? (n.logout(r.token), t.clearCookie("token"), t.clearCookie("username"), t.json({
                err: !1
            })) : (t.status(400), t.json({
                err: "Missing User or Token."
            }))
        }), e.post("/auth/register", function(e, t) {
            var n = e.user,
                r = {
                    username: e.body.username || e.cookies.username,
                    password: e.body.password
                };
            if (r.username && r.password)
                if (u.registration) {
                    var o = e.headers["x-forwarded-for"] || e.connection.remoteAddress;
                    n.exist(function(e) {
                        if (e) t.status(409), t.json({
                            err: "User already exist."
                        });
                        else {
                            n.set({
                                password: i.default.SHA256(r.password).toString(),
                                username: r.username
                            });
                            var a = n.login(o, !1);
                            t.cookie("token", a.id, {
                                expires: a.expirationDate,
                                httpOnly: !0,
                                encode: String
                            }), t.cookie("username", n.username, {
                                expires: a.expirationDate,
                                httpOnly: !0,
                                encode: String
                            }), t.json({
                                err: !1,
                                token: a.id
                            })
                        }
                    })
                } else t.status(403), t.json({
                    err: "Registration is disabled."
                });
            else t.status(400), t.json({
                err: "Missing User or Password."
            })
        }), e.post("/auth/changepass", function(e, t) {
            var n = e.user,
                r = {
                    username: e.body.username || e.cookies.username,
                    oldPassword: e.body.oldpassword,
                    newPassorwd: e.body.newpassword
                };
            r.username && r.oldPassword && r.newPassorwd ? n.isPasswordValid(r.oldPassword) ? (n.set({
                password: i.default.SHA256(r.newPassorwd).toString()
            }), t.json({
                err: !1
            })) : (t.status(403), t.json({
                err: "Wrong User or Pass."
            })) : (t.status(400), t.json({
                err: "Missing User, Pass or new Pass."
            }))
        }), e.get("/auth/logged", function(e, t) {
            var n = e.user,
                r = e.body.token || e.cookies.token;
            t.json(n.isTokenValid(r))
        })
    }
}, function(e, t, n) {
    "use strict";

    function r(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function o(e, t) {
        e.emit("folder", t)
    }
    var i = n(2),
        a = r(i),
        s = n(0),
        u = r(s),
        l = n(6),
        c = r(l),
        f = n(7),
        d = r(f),
        h = new u.default({
            sync: !0
        }),
        p = new c.default("/" + __dirname + "/" + h.files.path, "");
    try {
        a.default.mkdirSync("/" + __dirname + "/" + h.files.tmp), a.default.mkdirSync("/" + __dirname + "/" + h.log.path)
    } catch (e) {
        "EEXIST" != e.code && console.error(e)
    }
    p.exist || (p.create(), p.initManualWatch(3e4)), e.exports = function(e) {
        return p.on("change", function(t) {
            return o(e.io, t.relativePath())
        }), e.ioSSL && p.on("change", function(t) {
            return o(e.ioSSL, t.relativePath())
        }), e.get("/folder", function(e, t) {
            t.header("Cache-Control", "no-cache"), t.json(p)
        }), e.get("/folder/:path((*)/?*)", function(e, t) {
            var n = e.params.path,
                r = (0, l.follow)(n, p);
            t.header("Cache-Control", "no-cache"), r ? t.json(r) : (t.status(404), t.json({
                err: n + " do not exist."
            }))
        }), e.put("/folder/:path((*)/?*)", function(e, t) {
            var n = e.params.path,
                r = (e.body.type, (0, f.parsePath)(n)),
                o = (0, l.follow)(r.path, p);
            if (o)
                if (o instanceof c.default)
                    if (o.findChild(r.fileName)) t.status(403), t.json({
                        err: "You can't create " + n + " because it already exist."
                    });
                    else {
                        var i;
                        switch (e.body.type) {
                            case "file":
                                i = new d.default(p.fullPath() + "/" + r.path + "/" + r.fileName, r.path);
                                break;
                            case "folder":
                            default:
                                i = new c.default(p.fullPath() + "/" + r.path + "/" + r.fileName, r.path)
                        }
                        i.create(), o.addChild(i), t.json(i)
                    }
            else t.status(400), t.json({
                err: "You can't create " + n + ", " + r.path + " is not a folder."
            });
            else t.status(404), t.json({
                err: "You can't create " + n + ", " + r.path + " do not exist."
            })
        }), e.post("/folder/:path((*)/?*)/rename", function(e, t) {
            var n = e.params.path,
                r = e.body.new.replace(/[^\w\s._-]/gi, "-"),
                o = (0, l.follow)(n, p);
            o ? r ? (o.rename(r), t.json(o)) : (t.status(400), t.json({
                err: "Missing new name."
            })) : (t.status(404), t.json({
                err: n + " do not exist."
            }))
        }), e.delete("/folder/:path((*)/?*)", function(e, t) {
            var n = e.params.path,
                r = (0, l.follow)(n, p);
            r ? (r.remove(), t.json(r)) : (t.status(404), t.json({
                err: n + " do not exist."
            }))
        }), p
    }
}, function(e, t, n) {
    "use strict";

    function r(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }
    var o = n(1),
        i = r(o),
        a = n(4),
        s = r(a),
        u = n(6),
        l = n(7),
        c = r(l),
        f = n(0),
        d = r(f),
        h = new d.default({
            sync: !0
        }),
        p = new i.default("File");
    e.exports = function(e, t) {
        function n(e, n, r) {
            var o = e.user,
                i = (0, u.follow)(r, t);
            i ? i instanceof c.default ? (p.info(o.username + " download " + i.name), i.download(n).then(function(e) {
                e && n.status(500), n.end()
            })) : (n.status(405), n.json({
                err: "You can't download " + r + " because it's a folder."
            })) : (n.status(404), n.json({
                err: r + " do not exist."
            }))
        }
        e.get("/dl/:file(*)", function(e, t) {
            n(e, t, s.default.Rabbit.decrypt(e.params.file, h.server.masterKey).toString(s.default.enc.Utf8))
        })
    }
}, function(e, t, n) {
    "use strict";

    function r(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function o(e, t, n) {
        e.emit("torrent", {
            code: n,
            peer: t
        })
    }

    function i(e, t) {
        e.emit("peer-" + t.uid, t)
    }
    var a = n(3),
        s = (r(a), n(33)),
        u = r(s),
        l = n(35),
        c = r(l),
        f = new c.default;
    e.exports = function(e, t) {
        var n = new u.default({
            baseFolder: t
        });
        n.on("new", function(t) {
            return o(e.io, t, "new")
        }), n.on("done", function(t) {
            return o(e.io, t, "done")
        }), n.on("stop", function(t) {
            return o(e.io, t, "stop")
        }), n.on("error", function(t) {
            return o(e.io, t, "error")
        }), n.on("download", function(t) {
            return i(e.io, t)
        }), n.on("metadata", function(t) {
            return i(e.io, t)
        }), e.ioSSL && (n.on("new", function(t) {
            return o(e.ioSSL, t, "new")
        }), n.on("done", function(t) {
            return o(e.ioSSL, t, "done")
        }), n.on("stop", function(t) {
            return o(e.ioSSL, t, "stop")
        }), n.on("error", function(t) {
            return o(e.ioSSL, t, "error")
        }), n.on("download", function(t) {
            return i(e.ioSSL, t)
        }), n.on("metadata", function(t) {
            return i(e.io, t)
        })), e.get("/torrent", function(e, t) {
            t.header("Cache-Control", "no-cache"), t.json(Object.keys(n.peers).map(function(e) {
                return n.peers[e]
            }))
        }), e.post("/search/torrent", function(e, t) {
            var n = e.body.query;
            n ? f.search(n).then(function(e) {
                t.json(e)
            }).catch(function() {}) : (t.status(400), t.json({
                err: "Missing query."
            }))
        }), e.put("/torrent", function(e, t) {
            var r = e.body.magnet;
            if (/tcloud:.*/.test(r)) r = r.replace(/tcloud:/, ""), f.getTorrent({
                magnet: r
            }).then(function(e) {
                console.log(e);
                var r = n.download(e);
                t.json(r)
            }).catch(function(e) {
                console.log(e)
            });
            else if (r) {
                var o = n.download(r);
                t.json(o)
            } else t.status(400), t.json({
                err: "Missing magnet."
            })
        }), e.get("/peer", function(e, t) {
            t.header("Cache-Control", "no-cache"), t.json(n.peers)
        }), e.get("/peer/:uid(*)", function(e, t) {
            t.header("Cache-Control", "no-cache");
            var r = e.params.uid;
            n.peers[r] ? t.json(n.peers[r]) : (t.status(404), t.json({
                err: "Peer " + r + " do not exist."
            }))
        }), e.delete("/peer/:uid(*)", function(e, t) {
            var r = e.params.uid;
            n.peers[r] ? (n.peers[r].stop(), t.json(n.peers[r])) : (t.status(404), t.json({
                err: "Peer " + r + " do not exist."
            }))
        })
    }
}, function(e, t, n) {
    "use strict";

    function r(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function o(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function i(e, t) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !t || "object" != typeof t && "function" != typeof t ? e : t
    }

    function a(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
        e.prototype = Object.create(t && t.prototype, {
            constructor: {
                value: e,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var s = function() {
            function e(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                }
            }
            return function(t, n, r) {
                return n && e(t.prototype, n), r && e(t, r), t
            }
        }(),
        u = n(10),
        l = r(u),
        c = (n(11), n(1)),
        f = r(c),
        d = n(5),
        h = r(d),
        p = n(34),
        v = r(p),
        m = n(0),
        y = r(m),
        g = n(6),
        b = r(g),
        w = new y.default({
            sync: !0
        }),
        k = function(e) {
            function t(e) {
                o(this, t);
                var n = i(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, e));
                return e = e || {}, n.baseFolder = e.baseFolder || new b.default("/" + __dirname + "/" + w.files.path, ""), n.peers = {}, n.log = new f.default("Torrent"), n
            }
            return a(t, e), s(t, [{
                key: "download",
                value: function(e) {
                    var t = this,
                        n = new v.default({
                            magnet: e
                        });
                    return this.peers[n.uid] = n, this.peers[n.uid].on("done", function(e) {
                        return t.handlePeerDone(e)
                    }), this.peers[n.uid].on("stop", function(e) {
                        return t.handlePeerStop(e)
                    }), this.peers[n.uid].on("error", function(e) {
                        return t.handlePeerError(e)
                    }), this.peers[n.uid].on("download", function(e) {
                        return t.emit("download", e)
                    }), this.peers[n.uid].on("metadata", function(e) {
                        return t.emit("metadata", e)
                    }), this.emit("new", n), this.peers[n.uid]
                }
            }, {
                key: "handlePeerStop",
                value: function(e) {
                    this.emit("stop", e), this.cleanup(e)
                }
            }, {
                key: "handlePeerDone",
                value: function(e) {
                    var t = this,
                        n = e.metadata.fullPath,
                        r = __dirname + "/" + w.files.path,
                        o = r + "/" + e.metadata.name; - 1 === l.default.readdirSync(r).indexOf(e.metadata.name) ? l.default.rename(n, o, function(n) {
                        n && t.log.error(n), t.cleanup(e)
                    }) : this.cleanup(e), this.emit("done", e)
                }
            }, {
                key: "handlePeerError",
                value: function(e) {
                    this.log.error("Unable to download " + e.magnet), this.emit("error", e), delete this.peers[e.uid]
                }
            }, {
                key: "cleanup",
                value: function(e) {
                    var t = this;
                    e.metadata.path ? l.default.remove(e.metadata.fullPath, function() {
                        return delete t.peers[e.uid]
                    }) : delete this.peers[e.uid]
                }
            }]), t
        }(h.default);
    t.default = k
}, function(e, t, n) {
    "use strict";

    function r(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function o(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function i(e, t) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !t || "object" != typeof t && "function" != typeof t ? e : t
    }

    function a(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
        e.prototype = Object.create(t && t.prototype, {
            constructor: {
                value: e,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var s = function() {
            function e(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                }
            }
            return function(t, n, r) {
                return n && e(t.prototype, n), r && e(t, r), t
            }
        }(),
        u = n(11),
        l = r(u),
        c = n(5),
        f = r(c),
        d = n(4),
        h = r(d),
        p = n(9),
        v = r(p),
        m = n(2),
        y = r(m),
        g = function(e) {
            function t(e) {
                o(this, t);
                var n = i(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this));
                return e = e || {}, n.uid = n.generateUid(), n.magnet = e.magnet || e.link, n.metadata = {}, n.started = !0, n.idle = {
                    date: new Date,
                    timeout: 1e3
                }, n.magnet ? (n.child = l.default.fork(__dirname + "/module/torrentWorker", [n.magnet]), n.child.on("message", function(e) {
                    return n.handleMessage(JSON.parse(e))
                }), n.child.on("close", function(e) {
                    return n.handleMessage({
                        type: 0 === e ? "done" : "error"
                    })
                })) : n.emit("err", {
                    code: 404,
                    message: "No magnet or link provided."
                }), n
            }
            return a(t, e), s(t, [{
                key: "stop",
                value: function() {
                    this.child && this.child.send(JSON.stringify({
                        type: "stop"
                    }))
                }
            }, {
                key: "handleMessage",
                value: function(e) {
                    if (this.started) switch (this.metadata = e.metadata, e.type) {
                        case "metadata":
                            this.emit("metadata", this);
                            break;
                        case "download":
                            new Date - this.idle.date >= this.idle.timeout && (this.idle.date = new Date, this.emit("download", this));
                            break;
                        case "done":
                            this.started = !1, this.emit("done", this);
                            break;
                        case "stop":
                            this.started = !1, this.emit("stop", this);
                            break;
                        case "noPeers":
                            this.emit("noPeers", this);
                            break;
                        case "error":
                            this.started = !1, this.emit("error", this)
                    }
                }
            }, {
                key: "generateUid",
                value: function() {
                    var e = "" + v.default.rand().toString();
                    return h.default.SHA256(e).toString().substr(0, 10)
                }
            }, {
                key: "toJSON",
                value: function() {
                    var e = Object.assign({}, this.metadata);
                    return delete e.path, delete e.fullPath, {
                        magnet: this.magnet,
                        metadata: e,
                        uid: this.uid,
                        url: "/peer/" + this.uid
                    }
                }
            }, {
                key: "cleanup",
                value: function() {
                    y.default.unlink(this.magnet, function() {})
                }
            }]), t
        }(f.default);
    t.default = g
}, function(e, t, n) {
    "use strict";

    function r(e) {
        return e && e.__esModule ? e : {
            default: e
        }
    }

    function o(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var i = function() {
            function e(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var r = t[n];
                    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
                }
            }
            return function(t, n, r) {
                return n && e(t.prototype, n), r && e(t, r), t
            }
        }(),
        a = n(1),
        s = r(a),
        u = n(36),
        l = r(u),
        c = n(3),
        f = (r(c), n(0)),
        d = r(f),
        h = new d.default({
            sync: !0
        }),
        p = function() {
            function e() {
                var t = this;
                o(this, e), this.api = new l.default, this.log = new s.default("Search"), h.torrent.providers.forEach(function(e) {
                    return t.api.enableProvider(e)
                })
            }
            return i(e, [{
                key: "search",
                value: function(e) {
                    var t = this;
                    return this.log.info(e), new Promise(function(n, r) {
                        Promise.all([t.api.search(e, "Movies", 20), t.api.search(e, "TV", 20)]).then(function(e) {
                            var t = {
                                movie: e[0],
                                tv: e[1]
                            };
                            t.movie.forEach(function(e) {
                                e.magnet = "tcloud:" + Buffer.from(JSON.stringify(e)).toString("base64")
                            }), t.tv.forEach(function(e) {
                                e.magnet = "tcloud:" + Buffer.from(JSON.stringify(e)).toString("base64")
                            }), n(t)
                        }).catch(r)
                    })
                }
            }, {
                key: "getTorrent",
                value: function(e) {
                    var t = void 0;
                    return e.hasOwnProperty("url") || e.hasOwnProperty("magnet") && (t = JSON.parse(Buffer.from(e.magnet, "base64").toString())), this.api.getMagnet(t)
                }
            }]), e
        }();
    t.default = p
}, function(e, t) {
    e.exports = require("torrent-search-api")
}, function(e, t, n) {
    "use strict";
    var r = n(2),
        o = function(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }(r),
        i = JSON.parse(o.default.readFileSync("package.json"));
    e.exports = function(e, t) {
        e.get("/app/version", function(e, t) {
            t.end(i.version)
        })
    }
}]);